using System.Collections.Generic;
using UnityEngine;

public class MonopolyBoard : MonoBehaviour
{
    [SerializeField] List<MonopolyNode> route = new List<MonopolyNode>();

    void OnValidate()
    {
        route.Clear();
        foreach (Transform node in transform.GetComponentInChildren<Transform>()) 
        {
            MonopolyNode mn = node.GetComponent<MonopolyNode>();
            if (mn != null)
            {
                route.Add(mn);
            }
        }
    }

    void OnDrawGizmos()
    {
        if (route == null || route.Count < 2) return;

        Gizmos.color = Color.green;

        for (int i = 0; i < route.Count - 1; i++)
        {
            if (route[i] != null && route[i + 1] != null)
            {
                Gizmos.DrawLine(route[i].transform.position, route[i + 1].transform.position);
            }
        }
    }
}
